import React,{Component} from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux'
import '../App.css';


function mapStateToProps(state) {
  const props = { aa: state.test1.visibilityFilter};
  return props;
}

const mapDispatchToProps = dispatch => {
  return {
    onTodoClick: id => {
      dispatch({
        type:"SET_VISIBILITY_FILTER",
        id:1
      })
    },
    dispatch
  }
}

 class List extends Component{
   constructor(props){
     super(props);
   }

  state={
    deviceModel:"dpsa-12-123",
    deviceCode:"asdadsqdqsdadad123",
    devicePlate:"沪A908X67",
    deviceName:"上海1号车",
    lineName:"AI 71路",
  };
  componentDidMount() {
    console.log(this)
  };

  render(){
    const {deviceModel,deviceCode,devicePlate,deviceName,lineName} = this.state;
    return (
      <div>
        <div className="carInfoItem">
          <div className="car-info-name">设备型号</div><span>{deviceModel}</span>
        </div>
        <div className="carInfoItem">
          <div className="car-info-name">车架识别码</div><span>{deviceCode}</span>
        </div>
        <div className="carInfoItem">
          <div className="car-info-name">车牌号</div><span>{devicePlate}</span>
        </div>
        <div className="carInfoItem">
          <div className="car-info-name">车辆名称</div><span>{deviceName}</span>
        </div>
        <div className="carInfoItem">
          <div className="car-info-name">归属线路</div><span>{lineName}</span>
        </div>
      </div>
    )
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(List)