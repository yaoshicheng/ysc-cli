import React,{Component} from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux'
import '../App.css';

function mapStateToProps(state) {
  const props = { aa: state.test1.visibilityFilter};
  return props;
}

const mapDispatchToProps = dispatch => {
  return {
    onTodoClick: id => {
      dispatch({
        type:"SET_VISIBILITY_FILTER",
        id:1
      })
    },
    dispatch
  }
}

 class CarInfoManage extends Component{
   constructor(props){
     super(props);
   }

  state={
    deviceModel:"dpsa-12-123",
    deviceCode:"asdadsqdqsdadad123",
    devicePlate:"沪A908X67",
    deviceName:"上海1号车",
    lineName:"AI 71路",
  };
  componentDidMount() {
    console.log(this.context.store.getState())
  }

   naviToHome = () =>{
    const {onTodoClick} = this.props;
     onTodoClick();
     this.props.dispatch({
       type:"SET_VISIBILITY_FILTER",
       id:1
     })
    // this.props.history.push("/")
  };

  render(){
    const {deviceModel,deviceCode,devicePlate,deviceName,lineName} = this.state;
    return (
        <div className="App">
          <div className="flex-row" style={{width:"90%",marginLeft:"5%",marginTop:"30px"}}>
            <div style={{fontSize:"30px",fontWeight:"bold"}}>车辆信息</div>
            <div className="navi-home-btn" onClick={this.naviToHome}>返回首页</div>
          </div>
          <div className="indexBody" style={{textAlign:"left",marginTop:"50px"}}>
            <div>
              设备编号：<input/>
            </div>
            <hr style={{margin:"30px 0"}}/>
            <div>
              <div className="carInfoItem">
                <div className="car-info-name">设备型号</div><span>{deviceModel}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">车架识别码</div><span>{deviceCode}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">车牌号</div><span>{devicePlate}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">车辆名称</div><span>{deviceName}</span>
              </div>
              <div className="carInfoItem">
                <div className="car-info-name">归属线路</div><span>{lineName}</span>
              </div>
            </div>
          </div>
        </div>
    )
  }
}

  About.contextTypes = {
    store: PropTypes.object,
  };

export default connect(mapStateToProps,mapDispatchToProps)(CarInfoManage)