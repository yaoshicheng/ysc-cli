
import {test} from "../services/index"

const initialState ={
  visibilityFilter: 'SHOW_ALL',
};
const test1 = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_VISIBILITY_FILTER':
      return {
        visibilityFilter:"Fuck"
      }
    default:
      return state
  }
};

export default test1