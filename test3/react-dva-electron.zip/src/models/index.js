import { combineReducers } from 'redux'
import {test} from "../services/index"

const initialState ={
  visibilityFilter: 'SHOW_ALL',
  todos: [
  ]
};

const todos = async(state = initialState, action) => {
  console.log(state)
  switch (action.type) {
    case 'ADD_TODO':
      return ([111,222]);

    case 'TOGGLE_TODO':
      console.log(state)
      return state.todos.map(todo =>
        (todo.id === action.id)
          ? {...todo, completed: !todo.completed}
          : todo
      )
    default:
      return state
  }
};

const visibilityFilter = (state = 'SHOW_ALL', action) => {
  // switch (action.type) {
  //   case 'SET_VISIBILITY_FILTER':
  //     return action.filter
  //   default:
  //     return state
  // }
}

const toApp = combineReducers({
  todos,
  // visibilityFilter
})
export default toApp