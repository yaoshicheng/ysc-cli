
import {test} from "../services/index"

const initialState ={
  visibilityFilter: 'SHOW_ALL',
  todos: [
  ]
};

const test2 = (state = initialState, action) => {
  switch (action.type) {
    case 'ADD_TODO':
      return ([111,222]);

    case 'TOGGLE_TODO':
      return {
        visibilityFilter:"Yeah"
      }
      // return state.todos.map(todo =>
      //   (todo.id === action.id)
      //     ? {...todo, completed: !todo.completed}
      //     : todo
      // )
    default:
      return state
  }
};
export default test2