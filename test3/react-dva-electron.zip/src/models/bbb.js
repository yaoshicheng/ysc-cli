
export default {

  namespace: 'bbb',

  state: {
    name: '这是bbb的model'
  },

  subscriptions: {},

  effects: {},

  reducers: {},
};