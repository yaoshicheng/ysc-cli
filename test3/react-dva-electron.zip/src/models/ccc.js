export default {

  namespace: 'ccc',

  state: {
    name:'这是ccc的model'
  },

  subscriptions: {

  },

  effects: {

  },

  reducers: {

  },

};
